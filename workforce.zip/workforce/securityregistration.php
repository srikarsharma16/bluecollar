<!DOCTYPE html>
<!DOCTYPE html>
<?php

// php select option value from database

$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "loginsystem";

// connect to mysql database

$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// mysql select query
$query = "SELECT * FROM `Trainer`";

// for method 1

$result1 = mysqli_query($connect, $query);



?>
<html>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif}
body {font-size: 16px;}
img {margin-bottom: -8px;}
.mySlides {display: none;}
</style>
<style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

</style>

<body class="w3-content w3-black" style="max-width:1500px;">
  <body class="w3-content w3-black" style="max-width:1500px;">

  <div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="homepage.php" class="w3-bar-item w3-button"><b>HOME</b></a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
    <a href="security.php" class="w3-bar-item w3-button ">Go Back</a>
             </div>
  </div>
</div>
<br><br><br>

<!-- Header with Slideshow -->

<!-- The App Section -->

<!-- Modal -->
<!-- Clarity Section -->

  <div class="w3-row-padding">
    <div class="w3-col l4 m6">
      <br><br><br><br><br><br><br><img class="w3-image w3-round-large w3-hide-small w3-grayscale" src="images/11.jpg" alt="App" width="335" height="471"><br><br><br>
      <img class="w3-image w3-round-large w3-hide-small w3-grayscale" src="images/14.jpg" alt="App" width="335" height="471"><br><br>
      <img class="w3-image w3-round-large w3-hide-small w3-grayscale" src="images/11.jpg" alt="App" width="335" height="471"><br><br>
</div>
    <div class="w3-col l8 m6">
     <Center> <p><span class="w3-xlarge"></span> <p><span class="w3-xlarge"><h1 class="w3-jumbo"><b>REGISTRATION DONE HERE</b></h1></span>
      <h1 class="w3-xxxlarge w3-text-red"><b>GAURD THE PLACE</b></h1>
              </div><br><br></center>
                <form class="form-group" action="func.php" method="post" required>
                <Center><h1 class="w3-large"><b>NAME  : </b></h1> 
 <input type="text" name="name" class="form-control" required><br></Center>
                 <center> <h1 class="w3-large"><b>AGE :</b></h1> 
 <input type="text" name="age" class="form-control"><br></center>
 <center><h1 class="w3-large"><b>CITY</b></h1>
 <input type="text" name="weight" class="form-control"><br></center>
 <center><h1 class="w3-large"><b>STATE</b></h1> 
 <input type="text" name="height" class="form-control"><br> </center>
 <center><h1 class="w3-large"><b>MALE/FEMALE</b></h1>
   <input type="text" name="sex" class="form-control"><br> </center>
  <center><h1 class="w3-large"><b>QUALIFICATION</b> </h1>
                     <select id="cars">
                      <option value="volvo">SCHOOL</option>
  <option value="volvo">SSLC</option>
  <option value="saab">PUC</option>
  <option value="opel">DEGREE</option>
</select>
   </center>
                       <center><h1 class="w3-large"><b>PHONE NO :</b> </h1>
                     <input type="text" name="phone" class="form-control" required><br> </center>
                          <center><h1 class="w3-large"><b>EXPECTED SALARY :</b> </h1>
                     <input type="text" name="package" class="form-control" required><br> </center>
                    <center><h1 class="w3-large"><b>WORKING HOURS :</b></h1>
             
             <select><option value="volvo">PART TIME</option><br>
             <option value="volvo">FULL TIME</option><br>
           </select>
            <br></center>
            <center><div class="col-md-5">       
            
  <input type="submit" class="button" name="pat_submit" value="Register" required>                  <a href="func.php" class="btn btn-light"></a>
  <button type="reset"  class="button" value="Reset">Reset</button><br><br></center>
                </form>
               
      </div>
    </div></p>
    </div>
  </div>
</div>
</div>
</div>
<!-- Feat
ures Section -->


<!-- Footer -->
<footer class="w3-container w3-padding-32 w3-light-grey w3-center w3-xlarge">
  <div class="w3-section">
    <i class="fa fa-facebook-official w3-hover-opacity"></i>
    <i class="fa fa-instagram w3-hover-opacity"></i>
    <i class="fa fa-snapchat w3-hover-opacity"></i>
    <i class="fa fa-pinterest-p w3-hover-opacity"></i>
    <i class="fa fa-twitter w3-hover-opacity"></i>
    <i class="fa fa-linkedin w3-hover-opacity"></i>
  </div>
  <p class="w3-medium">Powered by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank" class="w3-hover-text-green">sriraj & swetha</a></p>
</footer>

<script>
// Slideshow
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block";  
}
</script>

</body>
</html>
