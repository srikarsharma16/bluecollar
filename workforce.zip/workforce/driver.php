<!DOCTYPE html>
<html>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
body {font-family: "Times New Roman", Georgia, Serif;}
h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
</style>
<body>

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="#home" class="w3-bar-item w3-button">Car Driving</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <a href="homepage.php" class="w3-bar-item w3-button">Back</a>
      <a href="#menu" class="w3-bar-item w3-button">Rules Needed to Follow</a>
      <a href="#register" class="w3-bar-item w3-button">Register</a>
      <a href="#test" class="w3-bar-item w3-button">Mock Test</a>
      <a href="#learn" class="w3-bar-item w3-button">Improvise</a>
      <a href="#contact" class="w3-bar-item w3-button">Contact</a>
    </div>
  </div>
</div>

<!-- Header -->
<header class="w3-display-container w3-content w3-wide" style="max-width:1600px;min-width:500px" id="home">
  <img class="w3-image" src="images/sri.jpg" alt="Hamburger Catering" width="1600" height="800">
  <div class="w3-display-bottomleft w3-padding-large w3-opacity">
    <h1 class="w3-xxlarge">car driving</h1>
  </div>
</header>

<!-- Page content -->
<div class="w3-content" style="max-width:1100px">

 

    <div class="w3-col m6 w3-padding-large">
      <h1 class="w3-center">CAR DRIVING</h1><br>
      <h5 class="w3-center">Need to protect the owner</h5>
      <p class="w3-large">Driving is the controlled operation and movement of a motor vehicle, including cars, motorcycles, trucks, and buses. Permission to drive on public highways is granted based on a set of conditions being met and drivers are required to follow the established road and traffic laws in the location they are driving.

<p class="w3-large w3-text-grey w3-hide-medium">Driving in traffic is more than just knowing how to operate the mechanisms which control the vehicle; it requires knowing how to apply the rules of the road (which ensures safe and efficient sharing with other users). An effective driver also has an intuitive understanding of the basics of vehicle handling and can drive responsibly.</p>
    </div>

    <div class="w3-row w3-padding-64" id="register">
  <h2>Click here to Apply Job</h2>
  <a href="driverapplication.php" class="w3-button w3-black">APPLY JOB</a>
</div>
       <div class="w3-row w3-padding-64" id="test">
  <h2>Click Here to take Mock Test</h2>
  <a href="test1.html" class="w3-button w3-black">MOCK TEST</a>
 
</div>
       <div class="w3-row w3-padding-64" id="Learn">
  <h2>Click Here to improve Driving Skills</h2>
  <a href="https://youtu.be/ASp_OTZ5fN8" class="w3-button w3-black">CLICK ME</a>
</div>

  </div>
  
  <hr>
  
  <!-- Menu Section -->
  <div class="w3-row w3-padding-64" id="menu">
    <div class="w3-col l6 w3-padding-large">
      <h1 class="w3-center">RULES NEED TO FOLLOW</h1><br>
     <p><b> Never Drink & Drive</b>
This is most important rule of driving. Alcohol causes a number of impairments that lead to the car accident. At low blood alcohol levels, causes the intoxication decrease the reaction time, lower the guessing power & inhibitions. At higher alcohol, blurred vision & loss of consciousness. Drunk & drive is crime & you have to pay heavy fine & also get you in jail. So, always remember this point.</p>

<p><b> Always Wear Seat Belt</b>
It is most essential factor to do for a car driver. If you wear a seat belt then it prevents you from being thrown around the inside of a crashing vehicle or thrown through the out of the vehicle during any accident & save your life. It reduced the risk of serious injury by 45% to 50%. In majority of car crashes, people have a greater chance of surviving if they wear a seat belt.<p>

<p><b> Follow Three Second Rule – Keep a Safe Distance</b>
It is highly recommended factor to the car driver to maintain a safe distance between the cars ahead. If the other vehicle makes a sudden turn or stop, then the driver requires enough time to handle that situation. I can be very difficult to estimate the distance while driving. So, you must have to follow “Three Second Rule”. It is simple rule, when the car ahead of you passes a permanent object on the side of road, start counting & at least 3 second passed before your car passes the same object & At night or in bad weather condition this second can be doubled.</p>

<p><b>Always Avoid Distractions </b>
While driving, any kind of distraction like talking on mobile phones, eating food etc is very dangerous for ours & also others. Drivers are not able to give full attention on the road & their reaction time becomes slow in critical conditions. Many studies show that this distraction decreases the reaction time.</p>

<p><b>Never Break Red Signal</b>
It is most common causes for road accidents. When you take a risk to run on red signal, another car will turn, it causes some serious accidents. So, never break red signal & always wait for green signal.</p>

<p><b>Always Drive In Speed Limit</b>
Generally youngster loves speed, but this fun cost you your life or permanent disabilities. It is one of the most important factor controls the traffic accidents. Almost every year over speeding more than 45% of the serious crashes. Due to over speeding your reaction times becomes very less. It is more dangerous & serious for our life. So, it is advisable to drive within the speed limit.</p>

<p><b> Watch Out For Drivers On the Road</b>
Sometimes it is depends how safely you drive you obeying all rules. Many times in the cases someone else crashes into you. So keep you’re an eye on the on road & others well by checking the mirrors & side streets. You can never assume the action of another driver on the road. Even after the left indicator shows, he might not take left turn.</p>
    
    <div class="w3-col l6 w3-padding-large">
      <img src="images/car.jpg" class="w3-round w3-image w3-opacity-min" alt="Menu" style="width:100%">
    </div>
  </div>

  <hr>

  <!-- Contact Section -->
  <div class="w3-container w3-padding-64" id="contact">
    <h1>Contact</h1><br>
    </p>
    <p class="w3-text-blue-grey w3-large"><b>bangalore, 42nd Living St, 43043 india, NY</b></p>
    <p>You can also contact us by phone 00553123-2323 or email catering@catering.com, or you can send us a message here:</p>
    <form action="/action_page.php" target="_blank">
  
      <p><input class="w3-input w3-padding-16" type="text" placeholder="Message \ Special requirements" required name="Message"></p>
      <p><button class="w3-button w3-light-grey w3-section" type="submit">SEND MESSAGE</button></p>
    </form>
  </div>
  
<!-- End page content -->
</div>


</body>
</html>