<!DOCTYPE html>
<html>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
body {font-family: "Times New Roman", Georgia, Serif;}
h1, h2, h3, h4, h5, h6 {
  font-family: "Playfair Display";
  letter-spacing: 5px;
}
</style>
<body>

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="#home" class="w3-bar-item w3-button">Security</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <a href="homepage.php" class="w3-bar-item w3-button">Back</a>
      <a href="#menu" class="w3-bar-item w3-button">Rules Needed to Follow</a>
       <a href="#reg" class="w3-bar-item w3-button">Register</a>
      <a href="#contact" class="w3-bar-item w3-button">Contact</a>
    </div>
  </div>
</div>

<!-- Header -->
<header class="w3-display-container w3-content w3-wide" style="max-width:1600px;min-width:500px" id="home">
  <img class="w3-image" src="images/11.jpg" alt="Hamburger Catering" width="1600" height="800">
  <div class="w3-display-bottomleft w3-padding-large w3-opacity">
    <h1 class="w3-xxlarge">Security</h1>
  </div>
</header>

<!-- Page content -->
<div class="w3-content" style="max-width:1100px">

 

    <div class="w3-col m6 w3-padding-large">
      <h1 class="w3-center">Security</h1><br>
      <h5 class="w3-center">Need to protect the owner</h5>
      <p class="w3-large">A security guard (also known as a security inspector, security officer, or protective agent) is a person employed by a government or private party to protect the employing party's assets (property, people, equipment, money, etc.) from a variety of hazards (such as waste, damaged property, unsafe worker behavior, criminal activity such as theft, etc.) by enforcing preventative measures. Security guards do this by maintaining a high-visibility presence to deter illegal and inappropriate actions, looking (either directly, through patrols, or indirectly, by monitoring alarm systems or video surveillance cameras) for signs of crime or other hazards (such as a fire), taking action to minimize damage (such as warning and escorting trespassers off property), and reporting any incidents to their clients and emergency services (such as the police or paramedics), as appropriate.[1]

<p class="w3-large w3-text-grey w3-hide-medium">Security officers are generally uniformed to represent their lawful authority to protect private property. Security guards are generally governed by legal regulations, which set out the requirements for eligibility (e.g., a criminal record check) and the permitted authorities of a security guard in a given jurisdiction. The authorities permitted to security guards vary by country and subnational jurisdiction. Security officers are hired by a range of organizations</p>
    </div>





<!--register-->

    <div class="w3-row w3-padding-64" id="reg">
  <h2>Click here to add Details</h2>
  <a href="securityregistration.php" class="w3-button w3-black">Click Me</a>
</div>

  </div>
  
  <hr>
  
  <!-- Menu Section -->
  <div class="w3-row w3-padding-64" id="menu">
    <div class="w3-col l6 w3-padding-large">
      <h1 class="w3-center">RULES NEED TO FOLLOW</h1><br>
     <p><b> Always Be Visible</b>
As one of the most basic rules security guards follow, being visible at all times is considered an effective deterrent to criminal and other illegal activity. Whether it is potential shoplifters in a store, employees who may be planning to steal items from a warehouse, or criminals trying to determine if they can break into cars at an apartment complex, having security guards who are highly-visible will often stop these activities before they start.</p>

<p><b>Be Alert and Vigilant</b>
Along with visibility, a security guard should also be alert and vigilant. Considered one of the most important rules for the night security guard, this will allow the guard to know when something looks or feels wrong. By combining their knowledge and experience with a keen sense of intuition, both people and property can remain safe.<p>

<p><b>Respond Quickly to an Emergency</b>
When a crisis situation occurs, security guards must be able to respond immediately. Whether it is a medical emergency, shooting, break-in, or other situation, the guard’s initial reaction can make all the difference. By being able to analyze the situation quickly and make the appropriate decisions, an emergency can be kept under control under first responders arrive on the scene.</p>

<p><b>Observations and Reports</b>
No matter their assignment, it is critical security guards be able to not only make keen observations of people and surroundings, but also prepare detailed reports for their supervisors, law enforcement, and others who need to be made aware of what is happening. Whether this involves written reports, making phone calls, or sending text messages, being able to send clear, concise, easy-to-understand reports can keep everyone safer.</p>

<p><b>Call for Help</b>
No matter how well-trained security guards may be, they also need to know when it is time to call for help. By getting police to the scene as fast as possible, it is likely many lives will be saved.</p>

<p><b>Always Follow Proper Procedures</b>
If there is one aspect of security guard rules that is perhaps most important, it is always following proper procedures. If this is not a top priority of a security guard, it is almost certain problems will develop. For example, by failing to properly search individuals before they enter a building or event, it becomes more likely a weapon will be smuggled inside, possibly leading to tragic consequences. Therefore, Ranger Guard and Investigations always requires officers to strictly follow established procedures at all times.</p>

<p><b>Maintain Order</b>
Whether at a concert, festival, sporting event, or other large gathering of people, it is imperative the security guard maintain order at all times. By doing so, they can prevent unnecessary violence, crowd stampedes, or other dangerous situations from developing</p>
    
    <div class="w3-col l6 w3-padding-large">
      <img src="images/13.jpg" class="w3-round w3-image w3-opacity-min" alt="Menu" style="width:100%">
    </div>
  </div>

  <hr>

  <!-- Contact Section -->
  <div class="w3-container w3-padding-64" id="contact">
    <h1>Contact</h1><br>
    </p>
    <p class="w3-text-blue-grey w3-large"><b>bangalore, 42nd Living St, 43043 india, NY</b></p>
    <p>You can also contact us by phone 00553123-2323 or email catering@catering.com, or you can send us a message here:</p>
    <form action="/action_page.php" target="_blank">
  
      <p><input class="w3-input w3-padding-16" type="text" placeholder="Message \ Special requirements" required name="Message"></p>
      <p><button class="w3-button w3-light-grey w3-section" type="submit">SEND MESSAGE</button></p>
    </form>
  </div>
  
<!-- End page content -->
</div>

<!-- Footer -->
<footer class="w3-center w3-light-grey w3-padding-32">
  <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-text-green">w3.css</a></p>
</footer>

</body>
</html>
